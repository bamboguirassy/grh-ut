import { FilterTableDirective } from './filter-table.directive';

describe('FilterTableDirective', () => {
  it('should create an instance', () => {
    const directive = new FilterTableDirective();
    expect(directive).toBeTruthy();
  });
});
