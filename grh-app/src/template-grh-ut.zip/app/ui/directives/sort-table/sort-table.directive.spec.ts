import { TCSortTableDirective } from './sort-table.directive';

describe('TCSortTableDirective', () => {
  it('should create an instance', () => {
    const directive = new TCSortTableDirective();
    expect(directive).toBeTruthy();
  });
});
