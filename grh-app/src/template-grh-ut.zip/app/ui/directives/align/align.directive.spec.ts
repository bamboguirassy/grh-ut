import { TCAlignDirective } from './align.directive';

describe('TCAlignDirective', () => {
  it('should create an instance', () => {
    const directive = new TCAlignDirective();
    expect(directive).toBeTruthy();
  });
});
