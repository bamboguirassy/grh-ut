import { TCBorderColorDirective } from './border-color.directive';

describe('TCBorderColorDirective', () => {
  it('should create an instance', () => {
    const directive = new TCBorderColorDirective();
    expect(directive).toBeTruthy();
  });
});
