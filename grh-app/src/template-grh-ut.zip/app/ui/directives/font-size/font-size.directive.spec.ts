import { FontSizeDirective } from './font-size.directive';

describe('FontSizeDirective', () => {
  it('should create an instance', () => {
    const directive = new FontSizeDirective();
    expect(directive).toBeTruthy();
  });
});
