import { TCFocusDirective } from './focus.directive';

describe('TCFocusDirective', () => {
  it('should create an instance', () => {
  });
});
