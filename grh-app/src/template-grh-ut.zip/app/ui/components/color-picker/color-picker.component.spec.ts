import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { TCColorPickerComponent } from './color-picker.component';

