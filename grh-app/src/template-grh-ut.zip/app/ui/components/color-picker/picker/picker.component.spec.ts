import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { TCPickerComponent } from './picker.component';


