export * from './avatar.component';
