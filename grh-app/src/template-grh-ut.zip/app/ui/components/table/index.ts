export * from './table.component';
export * from './col/col.component';
