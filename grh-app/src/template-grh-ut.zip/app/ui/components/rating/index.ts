export * from './rating.component';
