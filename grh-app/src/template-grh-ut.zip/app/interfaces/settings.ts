export interface IAppSettings {
  layout: string;
  boxed: boolean;
  sidebarOpened: boolean;
  sidebarBg?: string;
  sidebarColor?: string;
  topbarBg?: string;
  topbarColor?: string;
}
