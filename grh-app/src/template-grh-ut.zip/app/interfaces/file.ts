export interface IFile {
	name: string,
	size: string
}