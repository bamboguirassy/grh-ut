export * from './vertical.component';
