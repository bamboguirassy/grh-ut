export * from './settings.component';
