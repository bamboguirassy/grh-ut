export * from './horizontal.component';
