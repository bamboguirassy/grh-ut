export * from './payments.component';
