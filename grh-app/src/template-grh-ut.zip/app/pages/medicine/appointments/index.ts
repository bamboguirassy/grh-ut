export * from './appointments.component';
