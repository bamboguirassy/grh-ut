export * from './patients.component';
