export * from './departments.component';
