export * from './base-page.component';
