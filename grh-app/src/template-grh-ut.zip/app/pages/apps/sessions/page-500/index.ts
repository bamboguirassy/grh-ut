export * from './page-500.component';
