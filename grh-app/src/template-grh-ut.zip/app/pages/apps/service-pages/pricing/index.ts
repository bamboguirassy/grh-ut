export * from './pricing.component';
