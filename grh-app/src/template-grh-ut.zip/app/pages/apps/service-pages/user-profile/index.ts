export * from './user-profile.component';
