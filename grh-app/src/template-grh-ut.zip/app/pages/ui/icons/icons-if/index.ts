export * from './icons-if.component';
