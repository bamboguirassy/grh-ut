export * from './ngx-echarts.component';
