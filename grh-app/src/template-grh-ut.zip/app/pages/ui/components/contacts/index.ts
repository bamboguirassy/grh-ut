export * from './contacts.component';
