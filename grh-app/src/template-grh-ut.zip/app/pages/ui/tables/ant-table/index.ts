export * from './ant-table.component';
